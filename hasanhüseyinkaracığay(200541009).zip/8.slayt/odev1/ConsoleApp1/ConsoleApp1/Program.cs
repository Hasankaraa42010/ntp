﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            if (BitConverter.IsLittleEndian)
            {
                Console.WriteLine("Litle");
            }
            else
            {
                Console.WriteLine("Big");
            }
            int a = 46513;
            byte[] b = BitConverter.GetBytes(a);

            foreach (byte item in b)
            {
                Console.WriteLine(item);
            }
        }
    }
}
