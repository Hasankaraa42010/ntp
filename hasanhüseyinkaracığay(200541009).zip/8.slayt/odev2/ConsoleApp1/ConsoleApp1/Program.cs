﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] kaynak = { 1, 2, 0, 1, 4 };
            short[] hedef = new short[5];
            Buffer.BlockCopy(kaynak, 0, hedef, 0, 4);
            foreach (short item in hedef)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine(Buffer.GetByte(hedef,0));
            Buffer.SetByte(hedef, 5, 3);
            foreach (short item in hedef)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine(Buffer.ByteLength(kaynak);
            Console.WriteLine(Buffer.ByteLength(hedef);
        }
    }
}
