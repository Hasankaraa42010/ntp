﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    using System;
    class Dortgen
    {
        static int En = 8;
        static int Boy = 3;
        static void Main()
        {
            int Boy = 100;
            Console.WriteLine(En + "\n" + Boy);
            Console.ReadKey();
        }
    }
    //hata almadı çözüm yolu yok oyuzden  cıktı 8 ve 100

}
