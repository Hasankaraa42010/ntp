﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System: 
namespace ConsoleApp1
{

    class Toplama {
        public int X;
        public int Y;
        public Toplama(int x, int y) {
            X = x; Y = y; }

        public Toplama() : this(-1, -1) { }
        public Toplama(int x) : this(x, 1) { }
        public int Islem() {
            return X + Y; }
        public void Yaz() {

            Console.WriteLine(X);
            Console.WriteLine(Y);

        }
    } 
class Program
{
    static void Main()
    {
        Toplama t = new Toplama(5, 6);
        t.Yaz();
            Toplama y = new Toplama(5, 6);
            y.Yaz();
        }
    }
}
