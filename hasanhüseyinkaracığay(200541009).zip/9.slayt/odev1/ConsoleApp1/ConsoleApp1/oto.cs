﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class oto
    {
        protected double boy = 5;
        protected double agirlik = 800;
        protected String  renk = "sARI";
        public void Goster()
        {
            Console.WriteLine(boy); 
            Console.WriteLine(agirlik);
            Console.WriteLine(renk);

        }
    }
    class model1 : oto
    {
        public String tur;
        public int silindir;
        public int subap;
        public int tork;
        public int guc;
        public void ozellikYaz()
        {
            Console.WriteLine(boy);
            Console.WriteLine(agirlik);
            Console.WriteLine(renk);
            Console.WriteLine(tur);
            Console.WriteLine(subap);
            Console.WriteLine(tork);
        }
    }
    class model2 : oto
    {
        public double model_boy
        {
            get { return boy; }
            set{ boy = value; }
        }
        public double model_agirlik
        {
            get { return agirlik; }
            set { agirlik = value}
        }
        public String model_renk
        {
            get { return renk; }
            set { renk = value}
        }
        public String tur = "Hatbak";
        public int silindir=8;
        public int subap=16;
        public int tork=300;
        public int guc=200;
        public void ozellikYaz()
        {
            Console.WriteLine(tur);
            Console.WriteLine(model_boy);
            Console.WriteLine(model_agirlik);
            Console.WriteLine(model_renk);
            Console.WriteLine(tork);
            Console.WriteLine(guc);
        }
    }
}
