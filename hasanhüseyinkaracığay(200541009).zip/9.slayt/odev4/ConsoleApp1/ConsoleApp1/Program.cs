﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Y y = new Y(5);
            X yy = new X(6);
            int deneme = y.A;
            int deneme2 = yy.A;
        }
    }
}
