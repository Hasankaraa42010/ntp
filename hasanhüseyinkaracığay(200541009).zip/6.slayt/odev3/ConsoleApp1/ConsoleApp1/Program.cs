﻿using System;

namespace ConsoleApp1
{
    
    class Program
    {
        struct Ogrenci
        {
            public int numara;
            public String ad;
            public String soyad;
        }
        static void Main(string[] args)
        {
            Ogrenci ogrenci = new Ogrenci();
            ogrenci.numara = 123;
            ogrenci.ad = "Ali;";
            ogrenci.soyad = "türk";
            Ogrenci ogrenci2 = new Ogrenci();
            ogrenci2.numara = 123;
            Console.WriteLine(ogrenci2.ad);
            Console.WriteLine(ogrenci.soyad);

        }
    }
}
