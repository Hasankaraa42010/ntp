﻿using System;

namespace ConsoleApp1
{
    enum GUNLER : byte
    {
        PAZAARTESİ,SALI,ÇARŞAMBA,PERŞEMBE,CUMA,CUMAERTESİ,PAZAR
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine((int)GUNLER.PAZAARTESİ);
            Console.WriteLine((int)GUNLER.SA);
        }
    }
}
