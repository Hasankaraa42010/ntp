﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        class Sinif
 { public int Sayi;
 public Sinif(int sayi) { Sayi = sayi; }
 public static implicit operator int(Sinif a) { return a.Sayi; }
 }
    static void Main(string[] args)
        {
            Sinif a = new Sinif(50);
 int b = a; Console.WriteLine(b);
        }
    }
}
