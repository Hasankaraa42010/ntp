﻿using System;

namespace ConsoleApp1
{
    namespace isim1 { 
    class Deneme
    {
        public Deneme()
        {
            Console.WriteLine("Deneme 1");
        }
    }}
    namespace isim2
    {
        class Deneme
        {
            public Deneme()
            {
                Console.WriteLine("Deneme 2");
            }
        }
    }
        
    class Program
    {
        static void Main(string[] args)
        {
            isim1.Deneme d1 = new isim1.Deneme();
            isim2.Deneme d2 = new isim2.Deneme();
        }
    }
}
