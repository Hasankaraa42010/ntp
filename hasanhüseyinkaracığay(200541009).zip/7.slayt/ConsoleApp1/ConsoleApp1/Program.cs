﻿using System;

namespace ConsoleApp1
{
    class Deneme
    {
        public int a;
        public int b;
        public Deneme(int a,int b)
        {
            this.a = a;
            this.b = b;
        }
        public static int topla(int x,int y)
        {
            return x + y;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Deneme d = new Deneme(1, 2);
            Console.WriteLine(d.a);
            Console.WriteLine(Deneme.topla(2,5));
        }
    }
}
