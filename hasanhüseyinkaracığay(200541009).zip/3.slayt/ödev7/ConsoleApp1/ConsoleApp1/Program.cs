﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0, a, n;
            Console.Write("bir sayı girin :");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("artım miktarı :");
            a = Convert.ToInt32(Console.ReadLine());
            for (; i < n;)
            {
                Console.Write("{0}", i);
                i = i + a;
            }
        }
    }
}
