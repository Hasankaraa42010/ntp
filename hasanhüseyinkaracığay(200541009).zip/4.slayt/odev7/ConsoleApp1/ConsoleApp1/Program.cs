﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static int Faktoriyel(int a)
        {
            if (a==0)
            {
                return 1;
            }
            return Faktoriyel(a - 1) * a;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Sayi gir");
            int fak_değeri = Convert.ToInt32(Console.ReadLine());
Console.WriteLine();
            Console.WriteLine("Girmiş olduğunuz sayının faktöriyeli :" +
            Faktoriyel(fak_değeri));
        }
    }
}
