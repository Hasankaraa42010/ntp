﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void deger(int sayi)
        {
            sayi = 30;
        }
        static void Main(string[] args)
        {
            int x = 100;
            Console.WriteLine(x);
            deger(x);
            Console.WriteLine(x);
        }
    }
}
