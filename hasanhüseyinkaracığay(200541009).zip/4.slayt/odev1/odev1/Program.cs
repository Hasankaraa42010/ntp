﻿using System;

namespace odev1
{
    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int[] dizi = new int[20];
            char[] chr=new char[20];

            for (int i = 0; i < 20; i++)
            {
                dizi[i] = random.Next(1, 5);
                chr[i] = (char)random.Next(20, 126);

            }
            for (int i = 0; i < 20; i++)
            {
                Console.WriteLine("(0,2).deger {1,2}",i,dizi[i]);
                for (int j = 0; j < dizi[i]; j++)
                {
                    Console.WriteLine(chr[i]);
                }
                Console.WriteLine();
            }
        }
    }
}
