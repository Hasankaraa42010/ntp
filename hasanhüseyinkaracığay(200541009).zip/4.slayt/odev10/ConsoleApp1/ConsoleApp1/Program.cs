﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static int buyukBul(int a, int b)
        {
            if (a > b)
                return a;

            return b;
        }
        static int buyukBul3(int a, int b,int c)
        {
            return buyukBul(a, buyukBul(b, c));
        }
            static void Main(string[] args)
            {
            int s1, s2, s3;
            Console.WriteLine("Sayi gir");
            s1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Sayi gir");
            s2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Sayi gir");
            s3 = Convert.ToInt32(Console.ReadLine());
            int enBuyuk = buyukBul3(s1, s2, s3);
            Console.WriteLine(enBuyuk);
        }
        } }
  
