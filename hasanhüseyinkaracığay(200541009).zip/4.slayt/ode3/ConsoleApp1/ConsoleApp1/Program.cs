﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] dizi = new int[3][];
            dizi[0] = new int[] { 1, 2 };
            dizi[1] = new int[] { 3,5,4};
            dizi[2] = new int[] { 8,9,0};
            foreach (int[] item in dizi)
            {
                foreach (int eleman in item)
                {
                    Console.Write(eleman);
                }
                Console.WriteLine();
            }
        }
    }
}
